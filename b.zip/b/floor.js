let num=[2,7,10,20];
for(let j=0;j<num.length;j++){
    var flag=1;
    for(let i=2;i<=Math.floor(num[j]/2);i++){
        if(num[j]%i==0){
            console.log(num[j],'non prime');
            flag=0;
            break;
        }
        else{
            flag=1;
        }
    }
    if(flag==1){
        console.log(num[j],'prime');  
    }
}