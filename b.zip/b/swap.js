
let arr=[11,21,31,41,51,61,71];

for(i=0;i<arr.length;i++){
    temp=arr[i];
    arr[i]=arr[arr.length-1-i];
    arr[arr.length-1-i]=temp;
    break;
}
console.log(arr);
