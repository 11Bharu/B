let num=29;
    for(let i=2;i<=Math.floor(num/2);i++){
        var flag=1;
        if(num%i==0){
            console.log('non prime');
            flag=0;
            break;
        }
        else{
            flag=1;
        }
    }
    if(flag==1){
        console.log('prime');  
    }




