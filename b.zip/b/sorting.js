// function fun1(arr){
//     for(i=0;i<arr1.length;i++){

//         for(j=0;j<arr1.length;j++){
//             if(arr1[i]>arr1[j+1]){
//                 temp=arr1[i];
//                 arr1[i]=arr1[j+1];
//                 arr1[j+1]=temp;
//                 console.log(arr1);
                
//                 break;     
//             }
//             else{
//                 console.log(arr1); 
                
//             }  
//         }
//     }   
// }
// var arr1=[21,33,12,55];
// fun1();


let arr=[2,4,3,1,0,77,53,11];
for(let i=0;i<arr.length;i++){
    if(arr[i]>arr[i+1]){
        let temp=arr[i];
        arr[i]=arr[i+1];
        arr[i+1]=temp;
        i=-1;
    }   
}
console.log("sorted elements:"+arr);
